chrome.runtime.onInstalled.addListener(function() {

  const lucnen = chrome.contextMenus.create({
    "id": "lucnen",
    "title": "Lực Nến",
    "contexts": ["all"],
    "documentUrlPatterns": ["*://iqoption.com/*", "*://binomo.com/*"]
  });

  chrome.contextMenus.create({
    "id": "iqoption",
    "parentId": lucnen,
    "title": "IQ Option Token",
    "contexts": ["all"],
    "documentUrlPatterns": ["*://iqoption.com/*"]
  })

});

chrome.contextMenus.onClicked.addListener(function(clickData){
  if (clickData.menuItemId == "iqoption"){
    getIQToken()
  }
})

function getIQToken() {
    chrome.cookies.get({"url": "https://iqoption.com", "name": "ssid"}, (token) => {
      if(!token) {
        chrome.notifications.create('error'+new Date().getTime(), {
          type: 'basic',
          iconUrl: 'icons/128-gray.png',
          title: 'Mã không xác định!',
          message: 'Đăng nhập IQ Option trước khi thực hiện thao tác này.'
        }, function(notificationId) {});
      } else {
        copyToClipboard(token);
        chrome.notifications.clear('success', function(cleared) {
          var options = {
            type: 'basic',
            iconUrl: 'icons/128.png',
            title: 'Dìa dia!',
            message: 'IQ Option Token đã được sao chép.'
          };
          chrome.notifications.create('success', options, ()=>{});
        });
      }
    });
}

const copyToClipboard = token => {
  var inputFieldClear = document.createElement('textarea');
  inputFieldClear.value = token.value;
  document.body.appendChild(inputFieldClear);
  inputFieldClear.select();
  try {
    var successful = document.execCommand('copy');
    var msg = successful ? 'successful' : 'unsuccessful';
    document.body.removeChild(inputFieldClear);
    console.log('Copying text command was ' + msg);
  } catch (err) {
    console.log('Oops, unable to copy');
  }
};